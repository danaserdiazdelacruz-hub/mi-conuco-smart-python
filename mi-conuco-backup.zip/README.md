# mi-conuco-smart-python
Sistema de alertas agrícolas con Python, Flask y PostgreSQL.
